# Autumn Arcade

A mobile-first, single-page autumn mini-game website with:
- Catch the Falling Leaves (30-second basket game)
- Don't Miss the Leaf! (10-round reaction test)

## Run locally
Open `index.html` in a modern browser. No build tools or dependencies are required.

## Publish for QR-code access
1. Create a GitHub repository (for example, `autumn-arcade`).
2. Upload `index.html` to the repository root.
3. In repository Settings → Pages, publish from the `main` branch and `/ (root)`.
4. Once GitHub Pages gives you the site URL, create a QR code pointing to that URL.
5. Test the QR code on both iPhone and Android before the festival.

Best scores are stored in the player's browser using localStorage. They are not shared across devices and there is no central leaderboard in this first version.

No audio is used. The page does not collect names or personal information.
